#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""token-saver m1 本地账本日报

本地读取 OpenClaw 各 agent 的 sqlite 转录(transcript_events),聚合 token 用量:
  - 当日按模型明细 / 会话消耗 Top 归因
  - 近 7 天、本月累计
  - 阈值告警:日 > --daily-budget(默认 300万) 或 单会话 > --session-budget(默认 200万)
零 API 消耗,纯标准库,数据库只读打开。

口径纪律:缓存读(cacheRead)计入总量——资源包按原始 token 1:1 扣减,
缓存折扣只降现金价、不减包。面板"上下文规模"≠计费口径。
"""
import argparse
import collections
import datetime
import glob
import json
import os
import re
import sqlite3
import sys

TZ = datetime.timezone(datetime.timedelta(hours=8))  # Asia/Shanghai
try:  # Windows GBK 控制台兼容
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
DEFAULT_DAILY_BUDGET = 3_000_000
DEFAULT_SESSION_BUDGET = 2_000_000

OPENCLAW_ROOT = os.environ.get("OPENCLAW_HOME") or os.path.expanduser(r"~\.openclaw")
CENTRAL_DB = os.path.join(OPENCLAW_ROOT, "state", "openclaw.sqlite")
WORKSPACE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))  # scripts→token-saver→skills→workspace


def wan(n: int) -> str:
    return f"{n / 10000:,.1f}万" if n >= 10000 else str(n)


def agent_db_paths():
    """发现所有 agent 数据库(中央表优先,失败则 glob 兜底)。"""
    paths = []
    try:
        con = sqlite3.connect(f"file:{CENTRAL_DB.replace(os.sep, '/')}?mode=ro", uri=True)
        for (p,) in con.execute("SELECT path FROM agent_databases"):
            full = os.path.join(OPENCLAW_ROOT, p.replace("\\", "/"))
            if os.path.exists(full):
                paths.append(full)
        con.close()
    except Exception:
        pass
    if not paths:
        paths = glob.glob(os.path.join(OPENCLAW_ROOT, "agents", "*", "agent", "openclaw-agent.sqlite"))
    return sorted(set(paths))


def pretty_key(skey):
    if not skey:
        return None
    if skey.endswith(":main"):
        return "主会话(H先生)"
    if ":cron:" in skey:
        return "自动化任务"
    if ":subagent:" in skey:
        return "隐藏子代理"
    tail = skey.split(":")[-1]
    return tail[:8] if tail else None


def load_labels():
    """会话标签:中央 task_runs.label > 各agent session_windows.display_name > session_key 尾段。"""
    labels = {}
    try:
        con = sqlite3.connect(f"file:{CENTRAL_DB.replace(os.sep, '/')}?mode=ro", uri=True)
        for label, child_key in con.execute(
            "SELECT label, child_session_key FROM task_runs WHERE label IS NOT NULL AND child_session_key IS NOT NULL"
        ):
            m = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})", child_key or "")
            if m:
                labels.setdefault(m.group(1), label)
        con.close()
    except Exception:
        pass
    for db in agent_db_paths():
        try:
            a = sqlite3.connect(f"file:{db.replace(os.sep, '/')}?mode=ro", uri=True)
            for sid, skey, disp in a.execute("SELECT session_id, session_key, display_name FROM session_windows"):
                labels.setdefault(sid, disp or pretty_key(skey))
            a.close()
        except Exception:
            continue
    return labels


def iter_usage(records):
    """递归找 {usage:{input|totalTokens|cacheRead..}} 所在消息对象。"""
    def walk(obj):
        if isinstance(obj, dict):
            u = obj.get("usage")
            if isinstance(u, dict) and (u.get("totalTokens") or u.get("input") or u.get("cacheRead")):
                yield obj, u
            for v in obj.values():
                yield from walk(v)
        elif isinstance(obj, list):
            for v in obj:
                yield from walk(v)
    yield from walk(records)


def collect(db_paths):
    """返回 records 列表:{day, ts, model, session_id, input, output, cache_read, cache_write, total, cost}"""
    recs, seen = [], set()
    for db in db_paths:
        try:
            a = sqlite3.connect(f"file:{db.replace(os.sep, '/')}?mode=ro", uri=True)
        except Exception:
            continue
        try:
            cur = a.execute("SELECT event_json FROM transcript_events WHERE event_json LIKE '%totalTokens%'")
            for (ej,) in cur:
                try:
                    env = json.loads(ej)
                except Exception:
                    continue
                for msg, u in iter_usage(env):
                    rid = msg.get("responseId")
                    if rid and rid in seen:
                        continue
                    if rid:
                        seen.add(rid)
                    ts = msg.get("timestamp")
                    if isinstance(ts, str):
                        try:
                            ts = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp() * 1000
                        except Exception:
                            continue
                    if not isinstance(ts, (int, float)):
                        continue
                    day = datetime.datetime.fromtimestamp(ts / 1000, TZ).strftime("%Y-%m-%d")
                    cost = (u.get("cost") or {}).get("total")
                    recs.append({
                        "day": day, "ts": ts, "model": msg.get("model") or "unknown",
                        "session_id": None,  # 由外层按 db 行补
                        "input": int(u.get("input") or 0), "output": int(u.get("output") or 0),
                        "cache_read": int(u.get("cacheRead") or 0), "cache_write": int(u.get("cacheWrite") or 0),
                        "total": int(u.get("totalTokens") or 0), "cost": float(cost) if cost is not None else 0.0,
                    })
        finally:
            a.close()
    return recs


def collect_with_session(db_paths):
    """同 collect(),但带上 session_id(逐库聚合时补齐)。"""
    recs, seen = [], set()
    for db in db_paths:
        try:
            a = sqlite3.connect(f"file:{db.replace(os.sep, '/')}?mode=ro", uri=True)
        except Exception:
            continue
        try:
            cur = a.execute("SELECT session_id, event_json FROM transcript_events WHERE event_json LIKE '%totalTokens%'")
            for sid, ej in cur:
                try:
                    env = json.loads(ej)
                except Exception:
                    continue
                for msg, u in iter_usage(env):
                    rid = msg.get("responseId")
                    if rid and rid in seen:
                        continue
                    if rid:
                        seen.add(rid)
                    ts = msg.get("timestamp")
                    if isinstance(ts, str):
                        try:
                            ts = datetime.datetime.fromisoformat(ts.replace("Z", "+00:00")).timestamp() * 1000
                        except Exception:
                            continue
                    if not isinstance(ts, (int, float)):
                        continue
                    recs.append({
                        "day": datetime.datetime.fromtimestamp(ts / 1000, TZ).strftime("%Y-%m-%d"),
                        "ts": ts, "model": msg.get("model") or "unknown", "session_id": sid,
                        "input": int(u.get("input") or 0), "output": int(u.get("output") or 0),
                        "cache_read": int(u.get("cacheRead") or 0), "cache_write": int(u.get("cacheWrite") or 0),
                        "total": int(u.get("totalTokens") or 0),
                        "cost": float((u.get("cost") or {}).get("total") or 0.0),
                    })
        finally:
            a.close()
    return recs


def label_of(sid, labels):
    raw = labels.get(sid)
    if raw:
        return str(raw)[:20]
    return sid[:8] if sid else "未知会话"


def main():
    ap = argparse.ArgumentParser(description="token-saver 本地用量日报")
    ap.add_argument("--date", default=datetime.datetime.now(TZ).strftime("%Y-%m-%d"), help="YYYY-MM-DD,默认今天")
    ap.add_argument("--daily-budget", type=int, default=int(os.environ.get("TOKEN_SAVER_DAILY", DEFAULT_DAILY_BUDGET)))
    ap.add_argument("--session-budget", type=int, default=DEFAULT_SESSION_BUDGET)
    ap.add_argument("--top", type=int, default=8)
    ap.add_argument("--wechat", action="store_true", help="输出微信版(≤500字)并落盘")
    ap.add_argument("--quiet", action="store_true", help="只写文件不打控制台表")
    args = ap.parse_args()

    db_paths = agent_db_paths()
    recs = collect_with_session(db_paths)
    if not recs:
        print("未找到任何用量记录(检查 OPENCLAW_HOME 与 agent 数据库)")
        return 1

    day = args.date
    day_recs = [r for r in recs if r["day"] == day]
    day_total = sum(r["total"] for r in day_recs)
    day_in = sum(r["input"] for r in day_recs)
    day_out = sum(r["output"] for r in day_recs)
    day_cache = sum(r["cache_read"] for r in day_recs)
    day_cost = sum(r["cost"] for r in day_recs)

    by_model = collections.Counter()
    for r in day_recs:
        by_model[r["model"]] += r["total"]

    by_sess = collections.Counter()
    for r in day_recs:
        by_sess[r["session_id"] or "?"] += r["total"]

    labels = load_labels()
    dt = datetime.datetime.strptime(day, "%Y-%m-%d")
    week_days = [(dt - datetime.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
    week_total = sum(r["total"] for r in recs if r["day"] in week_days)
    month = day[:7]
    month_total = sum(r["total"] for r in recs if r["day"].startswith(month))

    alerts = []
    if day_total > args.daily_budget:
        alerts.append(f"日总量 {wan(day_total)} 超过日预算 {wan(args.daily_budget)}")
    for sid, t in by_sess.most_common():
        if t > args.session_budget:
            alerts.append(f"会话[{label_of(sid, labels)}] {wan(t)} 超单会话预算 {wan(args.session_budget)}")

    lines = []
    lines.append(f"# token 日报 · {day}")
    lines.append("")
    lines.append(f"- 生成:{datetime.datetime.now(TZ).strftime('%Y-%m-%d %H:%M')} | 口径:本地转录聚合,原始 token(含缓存读,资源包 1:1 扣减)")
    lines.append(f"- 今日总计:**{day_total:,} tokens**({wan(day_total)}) | 输入 {wan(day_in)} / 输出 {wan(day_out)} / 缓存读 {wan(day_cache)}")
    if day_cost:
        lines.append(f"- 牌价折算参考:${day_cost:.2f}(缓存折扣已含,实际以资源包扣减为准)")
    lines.append(f"- 近 7 天累计:{week_total:,}({wan(week_total)}) | 本月({month})累计:{month_total:,}({wan(month_total)})")
    lines.append("")
    lines.append("## 按模型")
    lines.append("")
    lines.append("| 模型 | tokens |")
    lines.append("|---|---|")
    for m, t in by_model.most_common():
        lines.append(f"| {m} | {t:,} |")
    lines.append("")
    lines.append(f"## 会话消耗 Top{args.top}")
    lines.append("")
    lines.append("| 会话 | tokens | 占比 |")
    lines.append("|---|---|---|")
    for sid, t in by_sess.most_common(args.top):
        pct = f"{t / day_total * 100:.0f}%" if day_total else "-"
        lines.append(f"| {label_of(sid, labels)} | {t:,} | {pct} |")
    lines.append("")
    lines.append("## 阈值检查")
    lines.append("")
    if alerts:
        for a in alerts:
            lines.append(f"- ⚠️ **ALERT**:{a}")
    else:
        lines.append(f"- ✅ 正常:日 {wan(day_total)} ≤ 预算 {wan(args.daily_budget)};最大会话 {wan(max(by_sess.values()))} ≤ {wan(args.session_budget)}")
    lines.append("")
    lines.append("> 数据来源:本地 OpenClaw 转录库(只读),零 API 消耗;与智谱控制台对账口径见 skills\\token-saver\\SKILL.md。")
    report = "\n".join(lines)

    os.makedirs(os.path.join(WORKSPACE, "reports"), exist_ok=True)
    md_path = os.path.join(WORKSPACE, "reports", f"token日报-{day}.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(report)

    wechat_path = None
    if args.wechat:
        wl = [f"【token 账本 {day}】"]
        wl.append(f"今日 {wan(day_total)} tokens(缓存读 {wan(day_cache)} 也 1:1 扣包)")
        wl.append(f"近7天 {wan(week_total)} | 本月 {wan(month_total)}")
        for i, (sid, t) in enumerate(by_sess.most_common(3), 1):
            wl.append(f"{i}.{label_of(sid, labels)} {wan(t)}")
        if alerts:
            wl.append("⚠️ " + ";".join(alerts[:2]))
        else:
            wl.append("✅ 未超阈值(日300万/会话200万)")
        wl.append("明细:reports/token日报-%s.md" % day)
        wechat = "\n".join(wl)
        wechat_path = os.path.join(WORKSPACE, "reports", f"token日报微信-{day}.txt")
        with open(wechat_path, "w", encoding="utf-8") as f:
            f.write(wechat)

    if not args.quiet:
        print(report)
        if wechat_path:
            print(f"\n=== 微信版({wechat_path}) ===")
            print(open(wechat_path, encoding="utf-8").read())
    else:
        print(f"written: {md_path}" + (f" + {wechat_path}" if wechat_path else ""))
        for a in alerts:
            print("ALERT:", a)

    return 2 if alerts else 0


if __name__ == "__main__":
    sys.exit(main())
