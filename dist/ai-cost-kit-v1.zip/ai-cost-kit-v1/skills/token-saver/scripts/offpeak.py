#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""token-saver m3 错峰调度顾问:现在跑重活,还是等半价?

口径来自 discount-radar 每日快照(官方页实抓,带来源链接):
  智谱 Coding Plan:工作日(周一~周五)14:00–18:00 为高峰,其余时段非高峰积分 5 折。
零 API 消耗。用法:python skills\\token-saver\\scripts\\offpeak.py [--vendor zhipu]
"""
import argparse
import datetime
import glob
import json
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

TZ = datetime.timezone(datetime.timedelta(hours=8))
WORKSPACE = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
SNAP_GLOB = os.path.join(WORKSPACE, "skills", "discount-radar", "data", "snapshot-*.json")


def radar_source(vendor_key):
    """取最新一份折扣雷达快照里该厂商的口径与来源链接。"""
    snaps = sorted(glob.glob(SNAP_GLOB))
    if not snaps:
        return None
    try:
        with open(snaps[-1], encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        return None
    for src in data.get("sources", []):
        if src.get("key") == vendor_key and src.get("status") == "ok":
            excerpt = ""
            for item in src.get("items", []):
                if item.get("discount") or item.get("price"):
                    excerpt = item.get("discount") or str(item.get("price"))[:80]
                    break
            return {
                "fetched_at": src.get("fetched_at", ""),
                "link": src.get("url", ""),
                "note": excerpt[:100],
            }
    return None


def is_peak(now):
    """智谱口径:周一至周五 14:00–18:00 高峰;周末全天非高峰。"""
    if now.weekday() >= 5:
        return False
    return 14 <= now.hour < 18


def next_change(now):
    """下一个高峰/非高峰切换时刻。"""
    cand = now
    for _ in range(10):  # 最多看 10 天
        for h in (14, 18):
            t = cand.replace(hour=h, minute=0, second=0, microsecond=0)
            if t > now and is_peak(t) != is_peak(now):
                return t
        cand = (cand + datetime.timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
    return None


def main():
    ap = argparse.ArgumentParser(description="错峰调度顾问")
    ap.add_argument("--vendor", default="zhipu", choices=["zhipu"], help="厂商口径(现支持智谱)")
    args = ap.parse_args()

    now = datetime.datetime.now(TZ)
    peak = is_peak(now)
    nxt = next_change(now)

    print(f"【错峰顾问 {now.strftime('%Y-%m-%d %H:%M %A')}】({args.vendor})")
    print(f"当前时段:{'🔴 高峰(原价)' if peak else '🟢 非高峰(积分 5 折)'}")
    if nxt:
        delta = nxt - now
        hours = int(delta.total_seconds() // 3600)
        mins = int(delta.total_seconds() % 3600 // 60)
        state_after = "高峰" if not peak else "非高峰"
        print(f"距切换:约 {hours}小时{mins:02d}分 后进入{state_after}({nxt.strftime('%m-%d %H:%M')})")
    print("建议:" + ("重活建议等非高峰再跑,或先做轻量本地工作。" if peak else "当前非高峰,适合跑重活(子代理/批量抓取/开发实验)。"))

    src = radar_source("bigmodel-coding")
    if src:
        print(f"口径来源:discount-radar 快照 {src['fetched_at'][:16]} | {src['link']}")
        if src["note"]:
            print(f"官方口径摘录:{src['note']}")
    else:
        print("口径来源:内置规则(工作日14:00–18:00高峰);未找到折扣雷达快照,建议先跑一次折扣雷达。")
    print("注:错峰收益体现在积分/现金侧;token 资源包按 1:1 扣减、不分时段。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
