#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""token-saver m2 预算熔断:开子代理/重活前的前置检查。零 API 消耗,纯本地读。

用法:
  python skills\\token-saver\\scripts\\budget_guard.py                    # 今日用量 vs 阈值
  python skills\\token-saver\\scripts\\budget_guard.py --session cffe309b # 加查某会话
  python skills\\token-saver\\scripts\\budget_guard.py --package 24443715 # 带包余额算续航

退出码: 0=OK  1=WARN(接近阈值)  2=STOP(超限)
STOP 时:先向 H先生汇报再动手,不擅自开工。
"""
import argparse
import collections
import datetime
import os
import sys

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from usage_report import agent_db_paths, collect_with_session, wan, TZ  # noqa: E402

WARN_RATIO = 0.8


def main():
    ap = argparse.ArgumentParser(description="预算熔断前置检查")
    ap.add_argument("--daily-budget", type=int, default=int(os.environ.get("TOKEN_SAVER_DAILY", 3_000_000)))
    ap.add_argument("--session-budget", type=int, default=2_000_000)
    ap.add_argument("--session", default=None, help="当前/目标会话 id 前缀(可选)")
    ap.add_argument("--package", type=int, default=None, help="资源包剩余 token(选填,算续航)")
    args = ap.parse_args()

    now = datetime.datetime.now(TZ)
    today = now.strftime("%Y-%m-%d")
    recs = collect_with_session(agent_db_paths())

    day_recs = [r for r in recs if r["day"] == today]
    day_total = sum(r["total"] for r in day_recs)
    by_sess = collections.Counter(r["session_id"] or "?" for r in recs if r["day"] == today)

    week_days = {(now - datetime.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)}
    week_total = sum(r["total"] for r in recs if r["day"] in week_days)
    avg7 = week_total / 7

    lines = [f"【预算熔断检查 {now.strftime('%Y-%m-%d %H:%M')}】"]
    lines.append(f"今日已用 {wan(day_total)} / 日预算 {wan(args.daily_budget)}({day_total / args.daily_budget * 100:.0f}%)")
    lines.append(f"近7天日均 {wan(int(avg7))}" + (f" | 包余 {wan(args.package)} ≈ 还可撑 {args.package / max(avg7, 1):.0f} 天" if args.package else ""))

    code = 0
    if day_total >= args.daily_budget:
        lines.append("🔴 STOP:今日已超日预算——重活先停,向 H先生汇报后再动。")
        code = 2
    elif day_total >= args.daily_budget * WARN_RATIO:
        lines.append("🟡 WARN:今日用量已接近日预算——重活从简,优先半价时段。")
        code = max(code, 1)
    else:
        lines.append("🟢 OK:今日余量充足。")

    if args.session:
        sess_total = sum(t for s, t in by_sess.items() if args.session.lower() in (s or "").lower())
        lines.append(f"会话[{args.session}] 今日 {wan(sess_total)} / 单会话预算 {wan(args.session_budget)}")
        if sess_total >= args.session_budget:
            lines.append("🔴 该会话超预算:收口当前任务,勿再开二阶段。")
            code = max(code, 2)
        elif sess_total >= args.session_budget * WARN_RATIO:
            lines.append("🟡 该会话接近预算:准备收口。")
            code = max(code, 1)

    print("\n".join(lines))
    return code


if __name__ == "__main__":
    sys.exit(main())
