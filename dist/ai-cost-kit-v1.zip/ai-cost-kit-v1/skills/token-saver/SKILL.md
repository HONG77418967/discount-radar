---
name: token-saver
description: 查用量/花了多少/token账本/省token/熔断/错峰时使用——本地出 token 报表、预算熔断与错峰建议,零 API 消耗。触发词:查用量、今天花了多少、token账本。
---

# token-saver(省token管家)v0.1 — m1 本地账本日报

## 用途

本地读取 OpenClaw 各 agent 的 sqlite 转录库(只读、零 API 消耗),产出:

1. **当日总量**——输入/输出/缓存读分列,按模型明细;
2. **会话消耗 Top 归因**——哪个会话在烧钱(自动带任务标签);
3. **近 7 天 / 本月累计**;
4. **阈值检查**——日 >300万 或 单会话 >200万 → ALERT(退出码 2,可接自动化)。
5. **预算熔断**(m2)——开子代理/重活前的前置检查,三色灯 OK/WARN/STOP。
6. **错峰顾问**(m3)——现在跑重活还是等半价,口径来自折扣雷达实抓快照。

## 触发词

"查用量" / "今天花了多少" / "token 账本" / "用量日报" / "省token"

## 执行步骤

1. 查账本(默认今天):`python skills\token-saver\scripts\usage_report.py`(`--date` 查历史 / `--wechat` 微信版 / `--quiet` 供自动化)。
2. **重活/开子代理前先熔断**:`python skills\token-saver\scripts\budget_guard.py`——退出码 0=绿(可干) / 1=黄(从简) / 2=红(停下先向 H先生汇报);可选 `--session <id前缀>` 查会话、`--package <包余>` 算续航。
3. **排重活时间先问错峰**:`python skills\token-saver\scripts\offpeak.py`——高峰→建议等非高峰;非高峰→适合跑重活。
4. 日报落盘 `reports\token日报-<date>.md` + 微信版;向 H先生转述 ≤3 行要点,微信通道直接用微信版文本。

## 口径纪律(必读)

- **缓存读计入总量**:资源包按原始 token 1:1 扣减,缓存折扣只降现金价、不减包;面板"上下文规模"≠计费口径。
- 对账实证(2026-10-13):本脚本 2,658.9万 = 智谱控制台包扣 2,556万 + 免费包 ~103万,完全吻合。
- 长跑子代理是最大变量:每次工具调用重发全量上下文(10-13 事故:单会话 1,708万,占当日 64%)。

## 阈值(H先生 2026-10-13/14 拍板,可改)

- 日预算 **300万**(env `TOKEN_SAVER_DAILY` 或 `--daily-budget`);
- 单会话预算 **200万**(`--session-budget`);
- 超限动作:汇报 → 建议停子代理 → 重活移非高峰时段。

## 后续版本

- m2 钩子版:把熔断接进自动化/会话启动钩子(现版为手动前置检查);
- token 日报每日自动化(每日 09:00 推微信,约 2万 tokens/次,待 H先生点头);
- ClawHub/GitHub 发布(与 discount-radar 共用登录与发布链路)。

## 失败处理

- 找不到数据库:脚本自动读中央表 agent_databases,失败则 glob `agents/*/agent/openclaw-agent.sqlite`;确认 OPENCLAW_HOME 环境变量;
- 单行解析失败自动跳过,不影响整报(与 discount-radar 同哲学:单点失败不拖垮全局);
- Windows 控制台已强制 UTF-8 输出,无乱码风险。
