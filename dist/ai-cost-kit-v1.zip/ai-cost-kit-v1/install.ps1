﻿# AI 成本优化工具包 - 安装脚本
$ErrorActionPreference = "Stop"
$dest = Join-Path $env:USERPROFILE ".openclaw\workspace\skills"
New-Item -ItemType Directory -Force -Path $dest | Out-Null
$src = Join-Path $PSScriptRoot "skills"
Copy-Item (Join-Path $src "*") $dest -Recurse -Force
Write-Host "已安装到 $dest"
Write-Host "请重启 OpenClaw 会话后使用。"
