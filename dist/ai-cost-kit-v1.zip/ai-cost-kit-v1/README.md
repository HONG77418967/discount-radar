# AI 成本优化工具包 v1

两个 OpenClaw 技能，帮你把模型账单降下来：

- **discount-radar**：每天抓取 6 家模型厂商官方定价页，生成折扣日报，价格变动自动对比
- **token-saver**：本地读取 OpenClaw 用量记录，出 token 账本、预算熔断与错峰建议，零 API 消耗

## 安装（Windows / OpenClaw）

1. 解压本包
2. 右键 `install.ps1` → 使用 PowerShell 运行，或执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

3. 重启 OpenClaw 会话，技能自动生效

## 使用

- 说“跑一下折扣雷达” → 生成当日日报
- 说“查 token 用量” → 出本地账本
- 两个技能都不需要额外 API key（折扣雷达只用公开网页）

## 说明

- 技能会写入 `~/.openclaw/workspace/skills/`，不影响已有技能
- 卸载：删除对应技能目录即可
- 数据与脚本全部本地运行
